# -*cding:utf-8-*-
from django.urls import path
from rest_framework.routers import DefaultRouter
from vote.views import annunce, admin, user, upload, create, votes, account

router = DefaultRouter()
router.register('announce', annunce.AnnunceModelViewSet, basename='announce')
router.register('admin', admin.AdminModelViewset, basename='admin')
router.register('user1', user.UserModelViewSet, basename='user1')
router.register('vote', create.VoteModelViewSet, basename='vote')

urlpatterns = [
                  path('user', user.UserView.as_view()),
                  path('user/apiview', user.UserApiView.as_view()),
                  path('login', user.LoginApiView.as_view()),

                  # 公告信息
                  path('announce/info/', annunce.announce_info),  # 单条公告信息

                  path('upload/vote/cover', upload.UploadVoteCover.as_view()),  # 投票封面
                  path('create/vote/', create.CreateVoteApiView.as_view()),  # 创建投票
                  path('getvote/', votes.GetVotesApiView.as_view()),  # 获取投票的相关投票

                  path('vote/select/info/', votes.vote_select_info),  # 获取某一个投票的相关信息
                  path('vote/select/submit/', votes.vote_select_submit),  # 投票的提交
                  path('vote/detail/info/', votes.vote_detail_info),  # 查看创建的投票情况
                  path('vote/involve/info/', votes.vote_involve_info),  # 查看参与投票人的情况

                  # 账号管理
                  path('account/register/', account.account_register),  # 注册账号

                  # 登录
                  path('admin/login/', admin.admin_login),  # 管理员登录
                  path('admin/logout/', admin.admin_logout),  # 注销
                  path('admin/home/', admin.admin_home),  # 管理后台主页
                  path('admin/get/announce/', admin.admin_get_announce),
                  path('admin/get/user/', admin.admin_get_user),
                  path('admin/get/vote/', admin.admin_get_vote),
                  path('admin/get/involve/', admin.admin_get_involve),

              ] + router.urls
