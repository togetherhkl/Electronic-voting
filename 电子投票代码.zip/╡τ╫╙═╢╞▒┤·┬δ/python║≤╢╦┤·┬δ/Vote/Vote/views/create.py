# -*cding:utf-8-*-
from vote.utils.ImgSave import ImgSave
from django.http import JsonResponse,HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.viewsets import ModelViewSet
from django.views import View#使用django的视图
from vote import models
from vote import serializers

class CreateVoteApiView(APIView):
    def post(self,request):
        #获取图片路径中图片的名字
        image_path=request.data['votepack']['image']
        image_path=image_path.split('/')
        image_name=image_path[len(image_path)-1]
        #获取用户ID
        user_instance=list(models.User.objects.filter(user_name=request.data['username']).values('id'))
        print(user_instance)
        user_id=user_instance[0]['id']
        print(user_id)
        #进入数据库或者写入区块链
        temp=models.Vote.objects.create(
            vote_title=request.data['votepack'] ['title'],
            vote_digest=request.data['votepack'] ['text'],
            vote_starttime=request.data['votepack'] ['startTime'],
            vote_deadtime=request.data['votepack'] ['endTime'],
            vote_cover=image_name,
            vote_multiple=request.data['votepack'] ['voteOptionCount'],
            vote_anonymity=request.data['votepack'] ['anonymous'],
            user_id=user_id,
        )
        #选票项存入数据库
        options=request.data['votepack'] ['options']
        for item in options:
            models.VoteOptions.objects.create(
                vote_id=temp.id,
                option_name=item
            )
        data={
            'msg':'yes',
        }
        return Response(data,status=status.HTTP_200_OK)

class VoteModelViewSet(ModelViewSet):
    queryset = models.Vote.objects.all()
    serializer_class = serializers.VoteModelSerializer