# -*cding:utf-8-*-
from rest_framework.viewsets import ModelViewSet
from rest_framework import status

from vote import models
from vote import serializers
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse,HttpResponse

class AnnunceModelViewSet(ModelViewSet):
    queryset = models.Announce.objects.all()
    serializer_class = serializers.AnnunceModelSerializer

@csrf_exempt
def announce_info(request):
    data={
        'msg':'fail'
    }
    if request.method=="POST":
        print(request.POST)
        announce_id=request.POST.get('announceid')
        announce_instance=models.Announce.objects.filter(id=announce_id).extra(select={
            "announce_date": "DATE_FORMAT(announce_date, '%%Y-%%m-%%d %%H:%%i')"
        }).values(
            'announce_title','announce_digest','announce_date','announce_cover','admin__admin_name'
        )
        data['announce']=list(announce_instance)
        data['msg']='success'
        return JsonResponse(data,status=status.HTTP_200_OK)
    return JsonResponse(data,status=status.HTTP_400_BAD_REQUEST)