# -*cding:utf-8-*-
from django.http import JsonResponse,HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.viewsets import ModelViewSet
from django.views import View#使用django的视图
from vote import models
from vote import serializers
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q, Count  # 引入Q查询，也就是多条件查询,和聚合函数count

class GetVotesApiView(APIView):
    '''
    获取需要投票的信息
    '''
    def post(self, request):
        # print(request.data)
        # 获取用户ID
        user_instance = list(models.User.objects.filter(user_name=request.data['username']).values('id'))
        # print(user_instance)

        user_id = user_instance[0]['id']
        #获取投票表中的投票
        vote_detail=models.Vote.objects.extra(select={
            "vote_deadtime": "DATE_FORMAT(vote_deadtime, '%%m-%%d %%H:%%i')",
            "vote_starttime":"DATE_FORMAT(vote_starttime, '%%m-%%d %%H:%%i')"
        }).values(
           'id','vote_title','vote_cover','vote_deadtime','vote_starttime','vote_anonymity','vote_multiple','user__user_name'
        )
        vote_detail=list(vote_detail)
        # 获取已经参与与未参与
        for item in vote_detail:
            temp=models.ParticipateVote.objects.filter(
                user_id=user_id,
                vote_id=item['id']
            )
            if not temp:
                item['participate']=0#没有参与
            else:
                item['participate']=1#参与
        data={
            'msg':'success',
            'vote_detail':vote_detail
        }
        return Response(data,status=status.HTTP_200_OK)

@csrf_exempt
def vote_select_info(request):
    '''发表界面所需要的信息'''
    data={
        'msg':'fail'
    }
    if request.method=="POST":
        print(request.POST)
        vote_id=request.POST.get('voteid')
        # print(vote_id)
        #获取某主题的信息
        vote_instance=models.Vote.objects.filter(id=vote_id).extra(select={
            "vote_deadtime": "DATE_FORMAT(vote_deadtime, '%%m-%%d %%H:%%i')"
        }).values(
            'id','vote_title','vote_cover','vote_multiple','vote_digest','vote_deadtime'
        )
        #获取某主题的选项
        options=models.VoteOptions.objects.filter(vote_id=vote_id).values(
            'id','option_name'
        )
        # 获取用户ID
        username = request.POST.get('username')
        user_instance = list(models.User.objects.filter(user_name=username).values('id'))
        user_id = user_instance[0]['id']
        # 添加是否选中记录按钮
        options = list(options)
        for item in options:
            item['check'] = False
        # 获取该用户，该主题的参与选票的信息
        participate=models.ParticipateVote.objects.filter(
            vote_id=vote_id,user_id=user_id
        )

        if not participate:#未参与
            partici=False
        else:
            partici=True#参与
            for item in options:
                # print(item.option_id)
                for i in participate:
                    if(item['id']==i.option_id):
                        item['check'] = True

        data={
            'vote_instance':list(vote_instance),
            'options':options,
            'partici':partici
        }
        return JsonResponse(data,status=status.HTTP_200_OK)
    return JsonResponse(data,status=status.HTTP_400_BAD_REQUEST)

@csrf_exempt
def vote_select_submit(request):
    data={
        'msg':'fail',
    }
    print(request.POST)
    if request.method=="POST":
        # 由姓名获取用户的ID
        username = request.POST.get('username')
        user_instance = list(models.User.objects.filter(user_name=username).values('id'))
        user_id = user_instance[0]['id']
        # 写入数据库
        if request.POST.get('type')=='radio':#单选
            temp=models.ParticipateVote.objects.create(
                user_id=user_id,
                vote_id=request.POST.get('vote_id'),
                option_id=request.POST.get('option_id')
            )
            if not temp:
                data['msg']='投票失败！'
            else:
                data['msg']='投票成功！'
            return JsonResponse(data,status=status.HTTP_200_OK)
        elif request.POST.get('type')=='multy':#多选
            # print(request.POST)
            # 写入数据库
            #获取多选票的选项id
            options=request.POST.get('option_list').split(',')
            for id in options:
                models.ParticipateVote.objects.create(
                    user_id=user_id,
                    vote_id=request.POST.get('vote_id'),
                    option_id=id,
                )
            data['msg']='投票成功'
            return JsonResponse(data, status=status.HTTP_200_OK)
        else:
            return JsonResponse(data, status=status.HTTP_400_BAD_REQUEST)
    return JsonResponse(data, status=status.HTTP_400_BAD_REQUEST)

@csrf_exempt
def vote_detail_info(request):
    '''
    获取参与投票的比列信息
    '''
    data = {
        'msg': 'fail'
    }
    if request.method == "POST":
        # print(request.POST)
        vote_id = request.POST.get('voteid')
        # print(vote_id)
        # 获取某主题的信息
        vote_instance = models.Vote.objects.filter(id=vote_id).values(
            'id', 'vote_title', 'vote_cover', 'vote_multiple', 'vote_digest','vote_anonymity'
        )
        # 获取某主题的选项
        options = models.VoteOptions.objects.filter(vote_id=vote_id).values(
            'id', 'option_name'
        )
        # 获取用户ID
        username = request.POST.get('username')
        user_instance = list(models.User.objects.filter(user_name=username).values('id'))
        user_id = user_instance[0]['id']
        #获取每个选的投票信息
        temp=models.ParticipateVote.objects.filter(vote_id=vote_id).values('option_id').annotate(count=Count('id'))
        #select option_id count(id) as count from ParticipateVote where vote_id=1 group by option_id
        countinfo=list(temp)
        # print(temp)
        options=list(options)
        # print(options)
        for i in options:
            flag=1
            for j in countinfo:
                if i['id']==j['option_id']:
                    i['count']=j['count']
                    flag=0
                    break
            if flag==1:
                i['count']=0
        # print(options)
        totalcount=models.ParticipateVote.objects.filter(vote_id=vote_id).all().count()
        # print(totalcount)
        for i in options:
            if totalcount!=0:
                i['percentage']=str(i['count']/totalcount*100)+"%"
            else:
                i['percentage']='0%'
        data = {
            'vote_instance': list(vote_instance),
            'options': options,
            'totalcount':totalcount
        }
        return JsonResponse(data,status=status.HTTP_200_OK)
    return JsonResponse(data, status=status.HTTP_400_BAD_REQUEST)

@csrf_exempt
def vote_involve_info(request):
    data={
        'msg':'fail'
    }
    if request.method == "POST":
        # print('参与信息：',request.POST)
        vote_id = request.POST.get('voteid')
        # print(vote_id)
        # 获取某主题的信息
        vote_instance = models.Vote.objects.filter(id=vote_id).values(
            'id', 'vote_title', 'vote_cover', 'vote_multiple', 'vote_digest'
        )
        # 获取某主题的选项
        options = models.VoteOptions.objects.filter(vote_id=vote_id).values(
            'id', 'option_name'
        )
        # 获取用户ID
        username = request.POST.get('username')
        user_instance = list(models.User.objects.filter(user_name=username).values('id'))
        user_id = user_instance[0]['id']
        # 获取每个选的投票信息
        temp = models.ParticipateVote.objects.filter(vote_id=vote_id).values('option_id').annotate(count=Count('id'))
        # select option_id count(id) as count from ParticipateVote where vote_id=1 group by option_id
        countinfo = list(temp)
        # print(temp)
        options = list(options)
        # print(options)
        for i in options:
            flag = 1
            for j in countinfo:
                if i['id'] == j['option_id']:
                    i['count'] = j['count']
                    flag = 0
                    break
            if flag == 1:
                i['count'] = 0
        # print(options)
        totalcount = models.ParticipateVote.objects.filter(vote_id=vote_id).all().count()
        # print(totalcount)
        for i in options:
            if totalcount != 0:
                i['percentage'] = str(i['count'] / totalcount * 100) + "%"
            else:
                i['percentage'] = '0%'
        #获取投某个票的人名字
        print(options)
        tempoption=models.ParticipateVote.objects.filter(option_id=8).values('option_id','user_id','user__user_name')
        for item in options:
            temp=[]
            tempinstance=models.ParticipateVote.objects.filter(option_id=item['id']).values('option_id','user_id','user__user_name')
            tempinstance=list(tempinstance)
            for j in tempinstance:
                temp.append(j['user__user_name'])
            item['users']=temp
        print(options)
        data = {
            'vote_instance': list(vote_instance),
            'options': options,
            'totalcount': totalcount
        }


        return JsonResponse(data, status=status.HTTP_200_OK)
    return JsonResponse(data, status=status.HTTP_400_BAD_REQUEST)