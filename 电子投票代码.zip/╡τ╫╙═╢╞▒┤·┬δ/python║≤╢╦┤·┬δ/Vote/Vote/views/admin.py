# -*cding:utf-8-*-
from rest_framework.viewsets import ModelViewSet
from django.shortcuts import render,HttpResponse,redirect
from django import forms
from vote import models
from django.http import JsonResponse
from vote.utils.checkcode import CreateVerifyImg#验证码生成图片
from django.core.exceptions import ValidationError#引入错误提示
from vote.utils.encrypt import md5#md5的加密
from django.views.decorators.csrf import csrf_exempt


from vote import models
from vote import serializers

class AdminModelViewset(ModelViewSet):
    queryset = models.Admin.objects.all()
    serializer_class = serializers.AdminModelSerializer

class LoginForm(forms.Form):
    '''登录界面的表单'''
    username=forms.CharField(
        label='用户名',
        required=True,
        error_messages={#更改错误信息
          'required':'需要填入信息',
        },
        widget=forms.TextInput(attrs={'type':'text','class':'username','placeholder':'用户名'}),

    )
    password=forms.CharField(
        label='密码',
        required=True,
        widget=forms.PasswordInput(attrs={'class':'password','placeholder':'密码'},render_value=True)
        #render_value=True错误的信息不会被删除
    )
    #验证码
    verifycode=forms.CharField(
        label='验证码',
        required=True,
        widget=forms.TextInput(attrs={'type':'text','name':'img-code','placeholder':'请输入验证码'},)
    )
    def clean_password(self):
        pwd=self.cleaned_data.get('password')
        return md5(pwd)
def admin_logout(request):
    '''退出'''
    request.session.clear()
    return redirect('/api/admin/login/')
def admin_login(request):
    '''登录功能'''
    if request.method=="GET":#如果是get请求
        form=LoginForm()
        context={
            'form':form,
        }
        print(context)
        return render(request, 'login.html',context)
    # 如果是POST请求
    form=LoginForm(data=request.POST)
    context = {
        'form': form,
    }
    if form.is_valid():#输入的为有效数据
        #把imagecode从form.cleaned_data中取出并去除
        verifycode=form.cleaned_data.pop('verifycode')
        if not verifycode:
            return render(request, 'login.html', context)
        #与session中的verifycode做对比（转化为小写）
        if verifycode.lower()!=request.session.get('verifycode').lower():
            form.add_error('verifycode','验证码错误')
            return render(request,'login.html',context)

        # row_obj=models.Users.objects.filter(**form.cleaned_data).first()
        row_obj=models.User.objects.filter(user_name=form.cleaned_data.get('username'),user_pwd=form.cleaned_data.get('password')).first()
        if not row_obj:
            form.add_error('password','账号或者密码输入错误')
            #提交错误的信息，别忘了在前端页面当中加入错误信息的引入{{form.usernaem.errors.0}}
            return render(request,'login.html',context)
        #验证正确，添加seesion
        request.session['info']={'id':row_obj.id,'name':row_obj.user_name}
        #设置session的有效时间,7天的有效时间
        request.session.set_expiry(60*60*24*7)
        #防止验证码复用，删除验证码
        request.session.delete('verifycode')
        return redirect('/api/admin/home/')
    # return render(request,'home_display.html',context)
    return HttpResponse('hhhh')

def admin_home(request):
    admin_name=request.session['info']['name']
    return render(request,'admin_home.html',{'admin_name':admin_name})
@csrf_exempt
def admin_get_announce(request):
    data={
        'data':[],
        'code':0,
    }
    announce_instance=models.Announce.objects.extra(
        select={
            "announce_date": "DATE_FORMAT(announce_date, '%%Y-%%m-%%d %%H:%%i')"
        }
    ).values(
        'id','announce_title','announce_digest','announce_date','announce_cover','admin__admin_name'
    )
    data['data']=list(announce_instance)
    print(data)
    return JsonResponse(data)

@csrf_exempt
def admin_get_user(request):
    data = {
        'data': [],
        'code': 0,
    }
    user_instance=models.User.objects.values(
        'user_name','user_pwd','user_phone'
    )
    data['data'] = list(user_instance)
    return JsonResponse(data)

@csrf_exempt
def admin_get_vote(request):
    data = {
        'data': [],
        'code': 0,
    }
    vote_instance = models.Vote.objects.extra(select={
        "vote_deadtime": "DATE_FORMAT(vote_deadtime, '%%Y-%%m-%%d %%H:%%i')",
        "vote_starttime": "DATE_FORMAT(vote_starttime, '%%Y-%%m-%%d %%H:%%i')"
    }).values(
        'id', 'vote_title', 'vote_cover','vote_digest', 'vote_deadtime', 'vote_starttime', 'vote_anonymity', 'vote_multiple',
        'user__user_name'
    )
    data['data'] = list(vote_instance)
    return JsonResponse(data)

@csrf_exempt
def admin_get_involve(request):
    data = {
        'data': [],
        'code': 0,
    }
    involve_instance=models.ParticipateVote.objects.values(
        'user_id','user__user_name','vote_id','vote__vote_title','option_id','option__option_name'
    )
    data['data'] = list(involve_instance)
    return JsonResponse(data)
