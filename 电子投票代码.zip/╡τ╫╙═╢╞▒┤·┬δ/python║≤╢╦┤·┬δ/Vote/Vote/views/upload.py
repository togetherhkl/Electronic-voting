# -*cding:utf-8-*-
import os
from vote.utils.ImgSave import ImgSave
from django.http import JsonResponse,HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.views import View#使用django的视图
class UploadVoteCover(APIView):
    def post(self,request):
        '''投票主题封面上传接口'''
        print(request.FILES)
        img = request.FILES.get('file')
        path = os.path.join('media', 'vote-cover-img')
        imgname, url = ImgSave(img, path)
        data = {
            'msg': '上传成功',
            'imgname': imgname,
            'url': url,
        }
        print(data)
        return Response(data, status=status.HTTP_200_OK)
