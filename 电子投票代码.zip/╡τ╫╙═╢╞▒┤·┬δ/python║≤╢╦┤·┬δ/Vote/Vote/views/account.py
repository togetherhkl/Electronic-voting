# -*cding:utf-8-*-
from vote.utils.ImgSave import ImgSave
from django.http import JsonResponse,HttpResponse
from rest_framework import status
from vote import models
from vote import serializers
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q
from vote.utils.encrypt import md5
from vote.utils.checkcode import CreateVerifyImg


@csrf_exempt
def account_register(request):
    data={
        'msg':'fail'
    }
    if request.method=="POST":
        username=request.POST.get('username')
        pwd=request.POST.get('password')
        phone=request.POST.get('phone')



        temp=models.User.objects.filter(Q(user_name=username)|Q(user_phone=phone)).all()
        if not temp:
            models.User.objects.create(user_name=username,user_pwd=md5(pwd),user_phone=phone)
            data['msg']='注册成功'
            return JsonResponse(data,status=status.HTTP_200_OK)
        else:
            data['msg']='用户名或手机号重复'
            return JsonResponse(data,status=status.HTTP_400_BAD_REQUEST)
    return JsonResponse(data,status=status.HTTP_400_BAD_REQUEST)

def image_code(request):
    '''请求验证码'''
    verifycode,img=CreateVerifyImg(120,60)
    #把验证码写入到session进行验证，在登录的时候做验证
    request.session['verifycode']=verifycode
    #设置session的超时时间60s
    request.session.set_expiry(60)
    return HttpResponse(img)