# -*cding:utf-8-*-
import json

from django.views import View#使用django的视图
from django.http.response import JsonResponse
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from vote import models
from vote import serializers
from vote.utils.encrypt import md5
from django.views.decorators.csrf import csrf_exempt

class UserModelViewSet(ModelViewSet):
    queryset = models.User.objects.all()
    serializer_class = serializers.UserModelSerializer

class UserView(View):
    def get(self,request):
        '''模型序列化器--单个模型'''
        # 1.获取数据集
        uerlist = models.User.objects.all()
        # 2.实例化序列化器
        serializer = serializers.UserModelSerializer(instance=uerlist, many=True)  # 因为是多个数据对象，所以需要设置many,也就是是否开启循环处理
        # 3.调用序列化对象的data属性方法获取转换后的数据
        data = serializer.data
        # 4.响应数据
        return JsonResponse(data=data, status=200, safe=False)

    def get4(self,request):
        '''反序列化--验证完成后--更新数据库'''
        #1.根据数据客户端访问的url地址，获取pk值
        pk=3
        try:
            user=models.User.objects.get(pk=pk)
        except:
            return JsonResponse({'error':'当前用户不存在'},status=400)
        #2.接受客端提交修改的数据
        data = {
            "user_name": "xiao hong",
            "user_pwd": "123456",
        }
        #3.修改操作的示例化对象
        # serializer=serializers.UserSerializer(instance=user,data=data)
        serializer = serializers.UserSerializer(instance=user, data=data,partial=True)#只修改某一部分
        #4.验证数据
        serializer.is_valid(raise_exception=True)
        #5.入库
        serializer.save()
        # serializer.save(owner=request.user)#传递不需要验证的数据到数据库
        #6返回数据
        return JsonResponse(serializer.data,status=201)
    def get3(self,request):
        '''反序列化--采用字段选项来验证数据-添加到数据库'''
        #1.接受客户端提交的数
        # data=json.dumps(request.body)
        data={
            "user_name":"xiao",
            "user_pwd":"123456",
            "user_phone":"17781020632"
        }
        ## 1.1实例化序列化器，获取序列化对象
        serializer=serializers.UserSerializer(data=data)
        ## 1.2验证数据,操作数据库
        serializer.is_valid(raise_exception=True)#抛出异常代码，代码不会往下执行
        # if ret:
        #     print(serializer.validated_data)
        #     return JsonResponse(dict(serializer.validated_data))
        # else:
        #     print(serializer.errors)
        #     return JsonResponse(dict(serializer.errors))
        #2.操作数据库
        serializer.save()
        #如果实例序列化器传入了instance则为更新，没有则为创建
        #3.放回结果
        return JsonResponse(serializer.data,status=201)
    def get2(self,request):
        '''序列化器-序列化阶段的调用--一个模型'''
        #1.获取数据集
        instance=models.User.objects.first()
        #2.实例化序列化器
        serializer=serializers.UserSerializer(instance=instance)
        #3.调用序列化对象的data属性方法获取转换后的数据
        data=serializer.data
        #4.响应数据
        return JsonResponse(data=data,status=200,safe=False)
    def get1(self,request):
        '''序列化器-序列化阶段的调用--多个模型'''
        #1.获取数据集
        uerlist=models.User.objects.all()
        #2.实例化序列化器
        serializer=serializers.UserSerializer(instance=uerlist,many=True)#因为是多个数据对象，所以需要设置many,也就是是否开启循环处理
        #3.调用序列化对象的data属性方法获取转换后的数据
        data=serializer.data
        #4.响应数据
        return JsonResponse(data=data,status=200,safe=False)

class UserApiView(APIView):
    def get(self,request):
        print(request)
        return Response({'msg':'ok'},headers={'sss':'sssss'},status=status.HTTP_201_CREATED)#自定义响应头，和状态玛


class LoginApiView(APIView):
    def post(self,request):
        '''登录功能请求，前端所需数据
            wx.setStorageSync('token', res.data.token);登录所需的taken
            wx.setStorageSync("imageUrl", res.data.avatarUrl);头像文件路径
            wx.setStorageSync("nickName", res.data.nickName);昵称
            wx.setStorageSync("status", res.data.status);状态码
            res.data.is_auth权限
            res.data.nickName昵称
            res.data.name用户名
            res.statusCode头部自带
            res.data.code
        '''
        print(request.data)
        #<QueryDict: {'name': ['xh'], 'password': ['123456'], 'token': ['']}>
        data={
            'msg':'fail'
        }
        username=request.data.get('username')
        user_instance=models.User.objects.filter(user_name=username).first()
        if not user_instance:
            data['msg']='用户名不存在'
            return Response(data,status=status.HTTP_400_BAD_REQUEST)
        if user_instance.user_pwd==md5(request.data.get('password')):
            data['msg'] = '登录成功'
            return Response(data,status=status.HTTP_200_OK)
        else:
            data['msg'] = '密码错误'
            return Response(data, status=status.HTTP_400_BAD_REQUEST)
        return Response(data, status=status.HTTP_400_BAD_REQUEST)
