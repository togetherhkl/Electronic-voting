$(document).ready(function () {
    Init()
    Announce()
    User()
    Vote()
    Involve()
})
function Init(){
     layui.use('table', function () {
            var table = layui.table;

            //展示已知数据
            table.render({
                elem: '#announce-data',
                url: '/api/admin/get/announce/'
                , toolbar: '#toolbarDemo'
                , cellMinWidth: 80
                , cols: [[ //标题栏
                    {type: 'checkbox'},
                    {field: 'id', title: 'ID', width: 80, sort: true}
                    , {field: 'announce_title', title: '标题', minWidth: 120, edit: 'text'}
                    , {field: 'announce_digest', title: '摘要', minWidth: 300, edit: 'textarea'}
                    , {field: 'announce_date', title: '发表时间', width: 200}
                    , {field: 'announce_cover', title: '封面', width: 150}
                    , {field: 'admin__admin_name', title: '发布者', width: 100}
                    , {fixed: 'right', title: '操作', width: 125, minWidth: 125, toolbar: '#barDemo'}
                ]]
                , editTrigger: 'dblclick'
                , skin: 'line' //表格风格
                , even: true
                , page: true,//是否显示分页
                //,limits: [5, 7, 10]
                // ,limit: 5 //每页默认显示的数量
            });
            // 工具栏事件
            table.on('toolbar(announce-data)', function (obj) {
                var id = obj.config.id;
                var checkStatus = table.checkStatus(id);
                var othis = lay(this);
                switch (obj.event) {
                    case 'getCheckData':
                        var data = checkStatus.data;
                        layer.alert(layui.util.escape(JSON.stringify(data)));
                        break;
                    case 'getData':
                        var getData = table.getData(id);
                        console.log(getData);
                        layer.alert(layui.util.escape(JSON.stringify(getData)));
                        break;
                    case 'isAll':
                        layer.msg(checkStatus.isAll ? '全选' : '未全选')
                        break;
                    case 'multi-row':
                        table.reload('announce-data', {
                            // 设置行样式，此处以设置多行高度为例。若为单行，则没必要设置改参数 - 注：v2.7.0 新增
                            lineStyle: 'height: 95px;'
                        });
                        layer.msg('开启多行');
                        break;
                    case 'default-row':
                        table.reload('announce-data', {
                            lineStyle: null // 恢复单行
                        });
                        layer.msg('已设为单行');
                        break;
                    case 'LAYTABLE_TIPS':
                        layer.alert('Table for layui-v' + layui.v);
                        break;
                }
                ;
            });
            //触发单元格工具事件
            table.on('tool(announce-data)', function (obj) { // 双击 toolDouble
                var data = obj.data;
                //console.log(obj)
                if (obj.event === 'del') {
                    layer.confirm('真的删除行么', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                } else if (obj.event === 'edit') {
                    layer.confirm('确认更新', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                }
            });

            //触发表格复选框选择
            table.on('checkbox(announce-data)', function (obj) {
                console.log(obj)
            });

            //触发表格单选框选择
            table.on('radio(announce-data)', function (obj) {
                console.log(obj)
            });

            // 行单击事件
            table.on('row(announce-data)', function (obj) {
                //console.log(obj);
                //layer.closeAll('tips');
            });
            // 行双击事件
            table.on('rowDouble(announce-data)', function (obj) {
                console.log(obj);
            });

            // 单元格编辑事件
            table.on('edit(announce-data)', function (obj) {
                var field = obj.field //得到字段
                    , value = obj.value //得到修改后的值
                    , data = obj.data; //得到所在行所有键值

                var update = {};
                update[field] = value;
                obj.update(update);
            });
        });
}
function Announce() {
    $('#announce').click(function () {
        temphtml = '<table class="layui-hide" id="announce-data" lay-filter="announce-data"></table>'
        $('#data-content').html(temphtml)


        layui.use('table', function () {
            var table = layui.table;

            //展示已知数据
            table.render({
                elem: '#announce-data',
                url: '/api/admin/get/announce/'
                , toolbar: '#toolbarDemo'
                , cellMinWidth: 80
                , cols: [[ //标题栏
                    {type: 'checkbox'},
                    {field: 'id', title: 'ID', width: 80, sort: true}
                    , {field: 'announce_title', title: '标题', minWidth: 120, edit: 'text'}
                    , {field: 'announce_digest', title: '摘要', minWidth: 300, edit: 'textarea'}
                    , {field: 'announce_date', title: '发表时间', width: 200}
                    , {field: 'announce_cover', title: '封面', width: 150}
                    , {field: 'admin__admin_name', title: '发布者', width: 100}
                    , {fixed: 'right', title: '操作', width: 125, minWidth: 125, toolbar: '#barDemo'}
                ]]
                , editTrigger: 'dblclick'
                , skin: 'line' //表格风格
                , even: true
                , page: true,//是否显示分页
                //,limits: [5, 7, 10]
                // ,limit: 5 //每页默认显示的数量
            });
            // 工具栏事件
            table.on('toolbar(announce-data)', function (obj) {
                var id = obj.config.id;
                var checkStatus = table.checkStatus(id);
                var othis = lay(this);
                switch (obj.event) {
                    case 'getCheckData':
                        var data = checkStatus.data;
                        layer.alert(layui.util.escape(JSON.stringify(data)));
                        break;
                    case 'getData':
                        var getData = table.getData(id);
                        console.log(getData);
                        layer.alert(layui.util.escape(JSON.stringify(getData)));
                        break;
                    case 'isAll':
                        layer.msg(checkStatus.isAll ? '全选' : '未全选')
                        break;
                    case 'multi-row':
                        table.reload('announce-data', {
                            // 设置行样式，此处以设置多行高度为例。若为单行，则没必要设置改参数 - 注：v2.7.0 新增
                            lineStyle: 'height: 95px;'
                        });
                        layer.msg('开启多行');
                        break;
                    case 'default-row':
                        table.reload('announce-data', {
                            lineStyle: null // 恢复单行
                        });
                        layer.msg('已设为单行');
                        break;
                    case 'LAYTABLE_TIPS':
                        layer.alert('Table for layui-v' + layui.v);
                        break;
                }
                ;
            });
            //触发单元格工具事件
            table.on('tool(announce-data)', function (obj) { // 双击 toolDouble
                var data = obj.data;
                //console.log(obj)
                if (obj.event === 'del') {
                    layer.confirm('真的删除行么', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                } else if (obj.event === 'edit') {
                    layer.confirm('确认更新', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                }
            });

            //触发表格复选框选择
            table.on('checkbox(announce-data)', function (obj) {
                console.log(obj)
            });

            //触发表格单选框选择
            table.on('radio(announce-data)', function (obj) {
                console.log(obj)
            });

            // 行单击事件
            table.on('row(announce-data)', function (obj) {
                //console.log(obj);
                //layer.closeAll('tips');
            });
            // 行双击事件
            table.on('rowDouble(announce-data)', function (obj) {
                console.log(obj);
            });

            // 单元格编辑事件
            table.on('edit(announce-data)', function (obj) {
                var field = obj.field //得到字段
                    , value = obj.value //得到修改后的值
                    , data = obj.data; //得到所在行所有键值

                var update = {};
                update[field] = value;
                obj.update(update);
            });
        });
    })

}

function User() {
    $('#user').click(function () {
        temphtml = '<table class="layui-hide" id="user-data" lay-filter="user-data"></table>'
        $('#data-content').html(temphtml)
        layui.use('table', function () {
            var table = layui.table;

            //展示已知数据
            table.render({
                elem: '#user-data',
                url: '/api/admin/get/user/'
                , toolbar: '#toolbarDemo'
                , cellMinWidth: 80
                , cols: [[ //标题栏
                    {type: 'checkbox'},
                    {field: 'id', title: 'ID', width: 80, sort: true}
                    , {field: 'user_name', title: '用户名', minWidth: 120}
                    , {field: 'user_phone', title: '手机号', width: 300, edit: 'textarea'}
                    , {field: 'user_pwd', title: '密码', minWidth: 200,edit: 'textarea'}
                    , {fixed: 'right', title: '操作', width: 125, minWidth: 125, toolbar: '#barDemo'}
                ]]
                , editTrigger: 'dblclick'
                , skin: 'line' //表格风格
                , even: true
                , page: true,//是否显示分页
                //,limits: [5, 7, 10]
                // ,limit: 5 //每页默认显示的数量
            });
            // 工具栏事件
            table.on('toolbar(user-data)', function (obj) {
                var id = obj.config.id;
                var checkStatus = table.checkStatus(id);
                var othis = lay(this);
                switch (obj.event) {
                    case 'getCheckData':
                        var data = checkStatus.data;
                        layer.alert(layui.util.escape(JSON.stringify(data)));
                        break;
                    case 'getData':
                        var getData = table.getData(id);
                        console.log(getData);
                        layer.alert(layui.util.escape(JSON.stringify(getData)));
                        break;
                    case 'isAll':
                        layer.msg(checkStatus.isAll ? '全选' : '未全选')
                        break;
                    case 'multi-row':
                        table.reload('user-data', {
                            // 设置行样式，此处以设置多行高度为例。若为单行，则没必要设置改参数 - 注：v2.7.0 新增
                            lineStyle: 'height: 95px;'
                        });
                        layer.msg('开启多行');
                        break;
                    case 'default-row':
                        table.reload('user-data', {
                            lineStyle: null // 恢复单行
                        });
                        layer.msg('已设为单行');
                        break;
                    case 'LAYTABLE_TIPS':
                        layer.alert('Table for layui-v' + layui.v);
                        break;
                }
                ;
            });
            //触发单元格工具事件
            table.on('tool(user-data)', function (obj) { // 双击 toolDouble
                var data = obj.data;
                //console.log(obj)
                if (obj.event === 'del') {
                    layer.confirm('真的删除行么', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                } else if (obj.event === 'edit') {
                    layer.confirm('确认更新', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                }
            });

            //触发表格复选框选择
            table.on('checkbox(user-data)', function (obj) {
                console.log(obj)
            });

            //触发表格单选框选择
            table.on('radio(user-data)', function (obj) {
                console.log(obj)
            });

            // 行单击事件
            table.on('row(user-data)', function (obj) {
                //console.log(obj);
                //layer.closeAll('tips');
            });
            // 行双击事件
            table.on('rowDouble(user-data)', function (obj) {
                console.log(obj);
            });

            // 单元格编辑事件
            table.on('edit(user-data)', function (obj) {
                var field = obj.field //得到字段
                    , value = obj.value //得到修改后的值
                    , data = obj.data; //得到所在行所有键值

                var update = {};
                update[field] = value;
                obj.update(update);
            });
        });
    })

}

function Vote() {
    $('#vote').click(function () {
        temphtml = '<table class="layui-hide" id="vote-data" lay-filter="vote-data"></table>'
        $('#data-content').html(temphtml)
        layui.use('table', function () {
            var table = layui.table;

            //展示已知数据
            table.render({
                elem: '#vote-data',
                url: '/api/admin/get/vote/'
                , toolbar: '#toolbarDemo'
                , cellMinWidth: 80
                , cols: [[ //标题栏
                    {type: 'checkbox'},
                    {field: 'id', title: 'ID', width: 80, sort: true}
                    , {field: 'vote_title', title: '标题', minWidth: 120}
                    , {field: 'vote_digest', title: '摘要', width: 300, edit: 'textarea'}
                    , {field: 'vote_starttime', title: '开始时间', minWidth: 100,edit: 'textarea'}
                    , {field: 'vote_deadtime', title: '结束时间', minWidth: 100,edit: 'textarea'}
                    , {field: 'vote_cover', title: '封面', minWidth: 150,edit: 'textarea'}
                    , {field: 'vote_anonymity', title: '是否匿名', minWidth: 100,edit: 'textarea'}
                    , {field: 'vote_multiple', title: '可选数目', minWidth: 100,edit: 'textarea'}
                    , {field: 'user__user_name', title: '发布者', minWidth: 100,edit: 'textarea'}
                    , {fixed: 'right', title: '操作', width: 125, minWidth: 125, toolbar: '#barDemo'}
                ]]
                , editTrigger: 'dblclick'
                , skin: 'line' //表格风格
                , even: true
                , page: true,//是否显示分页
                //,limits: [5, 7, 10]
                // ,limit: 5 //每页默认显示的数量
            });
            // 工具栏事件
            table.on('toolbar(vote-data)', function (obj) {
                var id = obj.config.id;
                var checkStatus = table.checkStatus(id);
                var othis = lay(this);
                switch (obj.event) {
                    case 'getCheckData':
                        var data = checkStatus.data;
                        layer.alert(layui.util.escape(JSON.stringify(data)));
                        break;
                    case 'getData':
                        var getData = table.getData(id);
                        console.log(getData);
                        layer.alert(layui.util.escape(JSON.stringify(getData)));
                        break;
                    case 'isAll':
                        layer.msg(checkStatus.isAll ? '全选' : '未全选')
                        break;
                    case 'multi-row':
                        table.reload('vote-data', {
                            // 设置行样式，此处以设置多行高度为例。若为单行，则没必要设置改参数 - 注：v2.7.0 新增
                            lineStyle: 'height: 95px;'
                        });
                        layer.msg('开启多行');
                        break;
                    case 'default-row':
                        table.reload('vote-data', {
                            lineStyle: null // 恢复单行
                        });
                        layer.msg('已设为单行');
                        break;
                    case 'LAYTABLE_TIPS':
                        layer.alert('Table for layui-v' + layui.v);
                        break;
                }
                ;
            });
            //触发单元格工具事件
            table.on('tool(vote-data)', function (obj) { // 双击 toolDouble
                var data = obj.data;
                //console.log(obj)
                if (obj.event === 'del') {
                    layer.confirm('真的删除行么', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                } else if (obj.event === 'edit') {
                    layer.confirm('确认更新', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                }
            });

            //触发表格复选框选择
            table.on('checkbox(vote-data)', function (obj) {
                console.log(obj)
            });

            //触发表格单选框选择
            table.on('radio(vote-data)', function (obj) {
                console.log(obj)
            });

            // 行单击事件
            table.on('row(vote-data)', function (obj) {
                //console.log(obj);
                //layer.closeAll('tips');
            });
            // 行双击事件
            table.on('rowDouble(vote-data)', function (obj) {
                console.log(obj);
            });

            // 单元格编辑事件
            table.on('edit(vote-data)', function (obj) {
                var field = obj.field //得到字段
                    , value = obj.value //得到修改后的值
                    , data = obj.data; //得到所在行所有键值

                var update = {};
                update[field] = value;
                obj.update(update);
            });
        });
    })

}

function Involve() {
    $('#involve').click(function () {
        temphtml = '<table class="layui-hide" id="involve-data" lay-filter="involve-data"></table>'
        $('#data-content').html(temphtml)


        layui.use('table', function () {
            var table = layui.table;

            //展示已知数据
            table.render({
                elem: '#involve-data',
                url: '/api/admin/get/involve/'
                , toolbar: '#toolbarDemo'
                , cellMinWidth: 80
                , cols: [[ //标题栏
                    {type: 'checkbox'},
                    {field: 'user_id', title: '用户ID', minWidth: 120, sort: true}
                    , {field: 'user__user_name', title: '用户名称', minWidth: 120 }
                    , {field: 'vote_id', title: '主题ID', minWidth: 300,sort: true}
                    , {field: 'vote__vote_title', title: '主题名称', minWidth: 300}
                    , {field: 'option_id', title: '选项ID', width: 120,sort: true}
                    , {field: 'option__option_name', title: '选项名称', width: 200}
                    , {fixed: 'right', title: '操作', width: 125, minWidth: 125, toolbar: '#barDemo'}
                ]]
                , editTrigger: 'dblclick'
                , skin: 'line' //表格风格
                , even: true
                , page: true,//是否显示分页
                //,limits: [5, 7, 10]
                // ,limit: 5 //每页默认显示的数量
            });
            // 工具栏事件
            table.on('toolbar(involve-data)', function (obj) {
                var id = obj.config.id;
                var checkStatus = table.checkStatus(id);
                var othis = lay(this);
                switch (obj.event) {
                    case 'getCheckData':
                        var data = checkStatus.data;
                        layer.alert(layui.util.escape(JSON.stringify(data)));
                        break;
                    case 'getData':
                        var getData = table.getData(id);
                        console.log(getData);
                        layer.alert(layui.util.escape(JSON.stringify(getData)));
                        break;
                    case 'isAll':
                        layer.msg(checkStatus.isAll ? '全选' : '未全选')
                        break;
                    case 'multi-row':
                        table.reload('involve-data', {
                            // 设置行样式，此处以设置多行高度为例。若为单行，则没必要设置改参数 - 注：v2.7.0 新增
                            lineStyle: 'height: 95px;'
                        });
                        layer.msg('开启多行');
                        break;
                    case 'default-row':
                        table.reload('involve-data', {
                            lineStyle: null // 恢复单行
                        });
                        layer.msg('已设为单行');
                        break;
                    case 'LAYTABLE_TIPS':
                        layer.alert('Table for layui-v' + layui.v);
                        break;
                }
                ;
            });
            //触发单元格工具事件
            table.on('tool(involve-data)', function (obj) { // 双击 toolDouble
                var data = obj.data;
                //console.log(obj)
                if (obj.event === 'del') {
                    layer.confirm('真的删除行么', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                } else if (obj.event === 'edit') {
                    layer.confirm('确认更新', function (index) {
                        obj.del();
                        layer.close(index);
                    });
                }
            });

            //触发表格复选框选择
            table.on('checkbox(involve-data)', function (obj) {
                console.log(obj)
            });

            //触发表格单选框选择
            table.on('radio(involve-data)', function (obj) {
                console.log(obj)
            });

            // 行单击事件
            table.on('row(involve-data)', function (obj) {
                //console.log(obj);
                //layer.closeAll('tips');
            });
            // 行双击事件
            table.on('rowDouble(involve-data)', function (obj) {
                console.log(obj);
            });

            // 单元格编辑事件
            table.on('edit(involve-data)', function (obj) {
                var field = obj.field //得到字段
                    , value = obj.value //得到修改后的值
                    , data = obj.data; //得到所在行所有键值

                var update = {};
                update[field] = value;
                obj.update(update);
            });
        });
    })

}

