from django.db import models


# Create your models here.
class User(models.Model):
    '''用户类'''
    user_name = models.CharField(verbose_name='用户名', max_length=20, unique=True)
    user_phone = models.CharField(verbose_name='用户手机', max_length=11, null=True, blank=True, unique=True)
    user_pwd = models.CharField(verbose_name='用户密码', max_length=128)


class Admin(models.Model):
    '''管理员类'''
    admin_name = models.CharField(verbose_name='管理员名', max_length=20, unique=True)
    admin_phone = models.CharField(verbose_name='管理员手机', max_length=11, null=True, blank=True, unique=True)
    admin_pwd = models.CharField(verbose_name='管理员密码', max_length=128)
    def __str__(self):
        return self.admin_name

class Announce(models.Model):
    '''公告类'''
    announce_title = models.CharField(verbose_name='公告标题', max_length=40)
    announce_digest = models.CharField(verbose_name='摘要', max_length=200)
    announce_content = models.TextField(verbose_name='公告内容')
    announce_date = models.DateTimeField(verbose_name='发布时间')
    announce_cover = models.CharField(verbose_name='公告封面', max_length=200)
    admin = models.ForeignKey(verbose_name='发布管理员',to='Admin',to_field='id',on_delete=models.CASCADE)

class Vote(models.Model):
    '''投票类'''
    vote_title = models.CharField(verbose_name='投票标题', max_length=40)
    vote_digest = models.CharField(verbose_name='描述', max_length=200)
    vote_starttime = models.DateTimeField(verbose_name='开始时间')
    vote_deadtime = models.DateTimeField(verbose_name='结束时间')
    vote_cover = models.CharField(verbose_name='投票封面', max_length=200)
    anonymity_choices = (
        (1, '非匿名'),
        (2, '匿名'),
    )
    vote_anonymity=models.SmallIntegerField(verbose_name='是否匿名',choices=anonymity_choices,default=2)
    vote_multiple=models.SmallIntegerField(verbose_name='多选情况',default=1)
    user = models.ForeignKey(verbose_name='发起用户', to='User', to_field='id', on_delete=models.CASCADE)

class VoteOptions(models.Model):
    '''投票选项类'''
    option_name = models.CharField(verbose_name='选项名', max_length=120)
    vote = models.ForeignKey(verbose_name='投票', to='Vote', to_field='id', on_delete=models.CASCADE)


class ParticipateVote(models.Model):
    '''参与投票类'''
    user=models.ForeignKey(verbose_name='参与者',to='User',to_field='id',on_delete=models.CASCADE)
    vote=models.ForeignKey(verbose_name='参与投票',to='Vote',to_field='id',on_delete=models.CASCADE)
    option=models.ForeignKey(verbose_name='选择选项',to='VoteOptions',to_field='id',on_delete=models.CASCADE)