# -*cding:utf-8-*-
from rest_framework import serializers
from vote import models

'''
ModelSerializer:模型序列化器
'''
class AnnunceModelSerializer(serializers.ModelSerializer):
    '''公告模型序 列化器'''
    admin_name=serializers.CharField(source='admin.admin_name',read_only=True)#序列化器的嵌套该模型下的对象admin里面的字段admin_name
    announce_date = serializers.DateTimeField(format='%Y-%m-%d')
    class Meta:
        model=models.Announce
        fields="__all__"
        # depth=1#展示1层
        fields=['id','announce_title','announce_digest','announce_content','announce_date','announce_cover','admin_name','admin']
class AdminModelSerializer(serializers.ModelSerializer):
    '''管理员模型 序列化器'''
    class Meta:
        model=models.Admin
        fields="__all__"
class UserModelSerializer(serializers.ModelSerializer):
    '''用户模型 序列化器'''
    # 1.转换的字段声明
    nickename=serializers.CharField(read_only=True,default='abc')#read_only序列化的时候才转换出去
    # 2.如果是模型，则需要添加模型信息class Meta:
    class Meta:
        model=models.User
        fields=['user_name','user_phone','user_pwd','nickename']
        #read_only_fields=[]#选填，只读字段列表，只在序列化时使用
        # extra_kwargs={#选填，额外字段申明
        #     'age':{
        #         'max_value':100
        #         'error_messages':{
        #              'max_vlue':'ss
        #
        #
        #              '
        #         }
        #     }
        # }

class VoteModelSerializer(serializers.ModelSerializer):
    '''投票主题序列化器'''
    user_name=serializers.CharField(source='user.user_name',read_only=True)
    vote_starttime=serializers.DateTimeField(format='%m-%d %H:%M',label='开始时间')
    vote_deadtime=serializers.DateTimeField(format='%m-%d %H:%M',label='结束时间')
    class Meta:
        model=models.Vote
        fields=['id','vote_title','vote_digest','vote_starttime','vote_deadtime','vote_cover','vote_anonymity','vote_multiple','user_name']

"""
Seriazlizer:基类序列化器
"""
class UserSerializer(serializers.Serializer):
    '''用户序列化器（非模型）'''
    # 1.转换的字段声明
    #客户端字段类型=serializer.字段类型（选项=选项值）
    id = serializers.IntegerField(read_only=True)  # 客户端提价的数据[反序列化阶段不会要求id的值
    user_name = serializers.CharField(max_length=20, required=True,error_messages={'max_length':'最大20'})  # 必填的字段
    #自定义错误消息
    user_pwd = serializers.CharField(max_length=128, required=True)
    user_phone = serializers.CharField(max_length=11, allow_null=True, allow_blank=True)  # 允许客户端可不填内容

    #2.如果是模型，则需要添加模型信息class Meta:

    #3.对象的验证
    ## 3.1验证单个字段
    def validate_user_name(self, data):#validate开头会被is_valid()调用
        if data in ['hhh','aaaa','sss']:
            raise serializers.ValidationError(detail='用户信息名不能是hhh，',code='validate_name')#抛出异常
        #验证成功，返回数据
        return data
    ## 3.2针对所有字段进行校验
    def validate(self, attrs):#attrs,序列化器的实例对象
        '''例子：密码，确认密码的两个字段的校验'''
        # if attrs['user_pwd']!= attrs['user_sure_pwd']:
        #     raise serializers.ValidationError(detail='密码不一致',code='user_pwd')
        # print(self.validated_data.get('user_pwd'))
        return attrs

    #4.模型操作方法
    ## 4.1create添加操作
    def create(self, validated_data):#固定名，固定参数
        user=models.User.objects.create(**validated_data)
        return user

    ## 4.2update更新
    def update(self, instance, validated_data):#固定名，固定参数
        # instance.user_name=validated_data['user_name']
        # instance.user_pwd=validated_data['user_pwd']
        # instance.user_phone=validated_data['user_phone']
        # instance.save()
        print(validated_data)
        for key,value in validated_data.items():
            setattr(instance,key,value)
        return instance