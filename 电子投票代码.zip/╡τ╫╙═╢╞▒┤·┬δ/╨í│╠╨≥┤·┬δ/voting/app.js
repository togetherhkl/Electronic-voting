// app.js


// 引入站点配置文件
import siteinfo from './siteinfo.js';
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
  globalData: {//全局变量公共数据
    userInfo: null,
    name:'',
    showType:1,//页面展示1：公告，2：参与，3：创建
    voteid:null,//传递投票的id选项
    announceid:null,//查看某条公告的id
  },
  //站点url信息aip地址
  api_root: siteinfo.siteroot + 'api/',
  port:'192.168.198.254',
  // 提示框
  hintComifg(tle) {
    wx.showToast({//消息提示框
      title: tle,
      icon: 'none',//不显示图标
      duration: 1000//提示延迟时间
    });
  },
    /**
   * 显示失败提示框
   */
  showError(msg, callback) {
    wx.showModal({//显示模态对话框
      title: '友情提示',
      content: msg,
      showCancel: false,//是否显示取消按钮
      success(res) {
        // callback && (setTimeout(function() {
        //   callback();
        // }, 1500));
        callback && callback();//如果未传入callback则不执行callback()函数
      }
    });
  },
   /**
   * post提交
   */
  _post_form(url, data, success, fail, complete, isShowNavBarLoading) {
    /**
     * url：访问的地址，192.168.61.132/api/url
     * data：传入的数据
     */
    let _this = this;//获取调用的界面
    isShowNavBarLoading || true;//
    // console.log(data)
    data.token = wx.getStorageSync('token');//获取本地缓存中指定的key,添加taken字段传递到后端
    // console.log(data)
    // 在当前页面显示导航条加载动画
    if (isShowNavBarLoading == true) {
      wx.showNavigationBarLoading();//导航条加载动画
    }
    wx.request({
      url: _this.api_root + url,
      header: {
        'content-type': 'application/x-www-form-urlencoded',//添加编码格式，把url中的参数准换成自己想要的
      },
      method: 'POST',
      data: data,
      success(res) {
        console.log(res)
        if (res.statusCode !== 200 || typeof res.data !== 'object') {
          _this.showError('网络请求出错');
          return false;
        }
        if (res.data.code === -1) {
          // 登录态失效, 重新登录
          wx.hideNavigationBarLoading();//隐藏导航条加载动画
          _this.showError(res.data.msg, function () {//如果传入失败函数，则显示 错误信息过后执行失败函数
            fail && fail(res);//如果fial为false则不执行fail（res），如果为true则执行fail(res)
          });
          return false;
        } else if (res.data.code === 0) {
          _this.showError(res.data.msg, function () {
            fail && fail(res);
          });
          return false;
        }
        success && success(res.data);//如果success为false则不执行success(res.data)，如果为true则执行success(res.data)
      },
      fail(res) {
        console.log(res);
        if (res.errMsg !== "request:fail interrupted") {
          _this.showError(res.errMsg, function () {
            fail && fail(res);//如果fial为false则不执行fail（res），如果为true则执行fail(res)
          });
        }
      },
      complete(res) {
        wx.hideNavigationBarLoading();//隐藏导航条加载动画
        wx.hideLoading();//隐藏登录加载
        complete && complete(res);
      }
    });
  },
  
  /**
   * 过滤表情符号
   */
  fliteremoji:function(str){
    str = str.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, "");
    return str;
  }

})
