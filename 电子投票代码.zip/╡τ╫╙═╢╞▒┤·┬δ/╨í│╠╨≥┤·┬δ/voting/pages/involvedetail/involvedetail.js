// pages/involvedetail/involvedetail.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    voteinfo:null,
    options:null,
    totalcount:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that=this
    wx.request({
      url: app.api_root+'vote/involve/info/', 
      method:'POST',
      data:{
        voteid:app.globalData.voteid,
        username:app.globalData.name,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
      },
      dataType:'json',
      success:function(res){
        console.log('投票人：',res)
        that.setData({
          voteinfo:res.data.vote_instance[0],
          options:res.data.options,
          totalcount:res.data.totalcount,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})