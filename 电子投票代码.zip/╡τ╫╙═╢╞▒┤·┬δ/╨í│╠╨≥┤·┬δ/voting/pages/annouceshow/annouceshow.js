// pages/annouceshow/annouceshow.js
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    announceinfo:[],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that=this
    wx.request({
      url: 'http://192.168.198.254:8002/api/announce/info/',
      dataType:'json',
      method:'POST',
      data:{'announceid':app.globalData.announceid},
      header: {
        'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
      },
      success:function(res){
        // console.log('公告信息：',res)
        that.setData({
          announceinfo:res.data.announce[0]
        })    
      }
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})