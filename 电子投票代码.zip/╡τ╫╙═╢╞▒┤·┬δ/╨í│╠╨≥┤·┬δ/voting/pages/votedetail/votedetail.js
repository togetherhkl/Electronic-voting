// pages/votedetail/votedetail.js
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    voteinfo:[],
    options:[],
    totalcount:null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that=this
    wx.request({
      url: app.api_root+'vote/detail/info/', 
      method:'POST',
      data:{
        voteid:app.globalData.voteid,
        username:app.globalData.name,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
      },
      dataType:'json',
      success:function(res){
        console.log('细节：',res)
        that.setData({
          voteinfo:res.data.vote_instance[0],
          options:res.data.options,
          totalcount:res.data.totalcount,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  SkipDetail(){
    let voteinfo=this.data.voteinfo
    if(voteinfo.vote_anonymity==2){//匿名投票不能查看
      wx.showModal({
        title: "温馨提示", // 提示的标题
        content: "只有非匿名投票才可以查看具体投票信息，若要查看请联系管理员", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelText: "取消", // 取消按钮的文字，最多4个字符
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
        success: function (res) {
            // console.log("接口调用成功的回调函数");
            if (res.confirm) {
                // console.log('用户点击确定')
                return
            } else if (res.cancel) {
                // console.log('用户点击取消')
                return
            }
        },
        fail: function () {
            // console.log("接口调用失败的回调函数");
        },
        complete: function () {
            // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");
        }
    })
    return
    }
    wx.navigateTo({
      url: '/pages/involvedetail/involvedetail',
    })
  }
})