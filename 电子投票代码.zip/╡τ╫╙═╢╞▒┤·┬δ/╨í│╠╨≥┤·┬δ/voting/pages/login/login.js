let app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '', // 手机号
    password: '', // 密码
    name:'',//用户名
  },

  // 获取用户名
  name(e) {
    this.setData({
      name: e.detail.value
    });
  },

  // 获取密码
  password(e) {
    this.setData({
      password: e.detail.value
    });
  },

  // 登录确定按钮
  butConfirm() {
    var _this = this,
      name = _this.data.name,
      password = _this.data.password;

    // 检查输入的信息
    if (name == "" || password == "") {
      app.hintComifg("请完善用户信息");
      return false;
    };

    // 后期对手机号进行验证
    // var myreg = /^[1]([3-9])[0-9]{9}$/;
    // if (!myreg.test(_this.data.phone)) {
    //   app.hintComifg("请输入正确的手机号");
    //   return false;
    // };
    wx.showLoading({
      title: "正在登录",
      mask: true//不允许点击后面
    });
    wx.request({
      url: 'http://192.168.198.254:8002/api/login',
      dataType:'json',
      method:'POST',
      data:{
        'username':name,
        'password':password,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
      },
      success:function(res){
        console.log(res)
        if(res.statusCode==400){
          wx.hideLoading();
          app.hintComifg(res.data.msg)
        }
        if(res.statusCode==200){
          wx.hideLoading();
          app.hintComifg(res.data.msg)
          app.globalData.name=name
          setTimeout(function(){
            wx.switchTab({//跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
              url: "/pages/home/home"
            });
          },1700)
        }
        
        }
    })
    // wx.login({//获取登录凭证code
    //   success(resLogin) {
    //     console.log(resLogin);
    //     //调用自定义post请求方法，这里只传入url,data,success函数
    //     // _post_form(url, data, success, fail, complete, isShowNavBarLoading) 
    //     app._post_form('login', {
    //       name: name,
    //       password: password
    //     }, res => {//一个参数的箭头函数,this指向page
    //       wx.hideLoading();
    //       app.hintComifg('登录成功~')
    //       app.globalData.name=name//设置登录的用户名
    //       setTimeout(aa => {
    //         wx.getStorageSync('');
    //         wx.setStorageSync('token', res.data.token);
    //         wx.setStorageSync("imageUrl", res.data.avatarUrl);
    //         wx.setStorageSync("nickName", res.data.nickName);
    //         wx.setStorageSync("status", res.data.status);
    //         if (res.data.is_auth == 0) {
    //           wx.setStorageSync("is_auth", true);
    //         };
    //         if (res.data.nickName == "") {
    //           wx.setStorageSync("nickName", res.data.name);
    //         };
    //         if (res.data.nickName == "") {
    //           wx.setStorageSync("imageUrl", "../../images/pic22.png");
    //         };
    //         wx.switchTab({//跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
    //           url: "/pages/home/home"
    //         });
    //       }, 1500)
    //     })
    //   },
    //   fail(err) {
    //     app.hintComifg("获取的登录凭证失败，请检查网络");
    //   }
    // });
  },

  // 注册
  enroll() {
    wx.navigateTo({
      url: '/pages/enroll/enroll',
    })
  },

  // 忘记密码
  findPassword() {
    wx.navigateTo({
      url: '/pages/findPassword/findPassword',
    })
  },

  // 微信登录
  getUserInfo(e) {
    let _this = this;
    var userInfo = {
      nickName: e.detail.userInfo.nickName,
      avatarUrl: e.detail.userInfo.avatarUrl
    };
    wx.showLoading({//显示 loading 提示框
      title: "正在登录",
      mask: true//是否显示透明蒙层，防止触摸穿透
    });
    wx.getSetting({//获取用户的当前设置。返回值中只会出现小程序已经向用户请求过的权限
      success(res) {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          wx.hideLoading();
          wx.getUserInfo({
            success(userRes) {
              wx.login({
                success(resLogin) {
                  console.log(resLogin)
                  // 发送用户信息
                  app._post_form('Login/login', {
                    code: resLogin.code,
                    user_info: JSON.stringify(userInfo)
                  }, result => {
                    console.log(result)
                    // if (result.data.is_auth == 1) {
                    wx.setStorageSync("is_auth", false);
                    wx.setStorageSync("imageUrl", userRes.userInfo.avatarUrl);
                    wx.setStorageSync("nickName", userRes.userInfo.nickName);
                    wx.setStorageSync('token', result.data.token);
                    // };
                    wx.switchTab({
                      url: "/pages/home/home"
                    });
                  });
                }
              });

            },
            fail(err) {
              app.hintComifg("获取用户信息失败");
            }
          })
        } else {
          app.hintComifg("请在微信设置中授权");
        }
      }
    })
  },

  /**
   * 授权成功 跳转回原页面
   */
  onNavigateBack() {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})