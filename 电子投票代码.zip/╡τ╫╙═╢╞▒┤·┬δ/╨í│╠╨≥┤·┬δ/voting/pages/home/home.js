const app = getApp();
// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    templist:[],//储存后端传过来的，公告，参与的投票，发起的投票的消息
    showType:1,//1:公告，2：参与投票，3：发起的投票
    createlist:[],//发起投票的列表
    particlist:[],//参与投票列表
    currentTime:new Date().toJSON().substring(5, 10) + ' ' + new Date().toTimeString().substring(0,6),
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    //每次加载区后端把公告的数据传过来
    this.setData({
      showType:app.globalData.showType
    })
    // console.log(app.globalData.showType)
    let that=this
    wx.request({
      url: 'http://192.168.198.254:8002/api/announce/',
      dataType:'json',
      method:'GET',
      success:function(res){
        console.log('公告：',res)
        that.setData({
          templist:res.data.reverse()//倒叙
        })
        // console.log(that.data.templist)
      }
    })
    //获取创建的投票信息
    wx.request({
      url: 'http://192.168.198.254:8002/api/vote/',
      dataType:'json',
      method:'GET',
      success:function(res){
        // console.log(res)
        that.setData({
          createlist:res.data.reverse()//倒叙
        })
        // console.log(that.data.templist)
      }
    })
    //获取参与投票的信息
    wx.request({
      url: 'http://192.168.198.254:8002/api/getvote/',
      dataType:'json',
      method:'POST',
      data:{'username':app.globalData.name},
      success:function(res){
        console.log(res)
        that.setData({
          particlist:res.data.vote_detail.reverse()
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  Create_btn(){
    /**
     * 查看创建的投票
     */
    let name=app.globalData.name
    if (!name) {
      wx.showModal({
        title: '提示',
        content: '请您先登录',
        success(res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login',
            });
          } else if (res.cancel) {
            wx.switchTab({
              url: '/pages/home/home',
            });
          }
        }
      });
      return
    } 
    
    app.globalData.showType=3
    this.setData({
      showType:3,
    })
  },
  Paticipate_btn(){
    /**
     * 参与投票界面
     */
    let name=app.globalData.name
    if (!name) {
      wx.showModal({
        title: '提示',
        content: '请您先登录',
        success(res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login',
            });
          } else if (res.cancel) {
            wx.switchTab({
              url: '/pages/home/home',
            });
          }
        }
      });
      return
    } 
    app.globalData.showType=2
    this.setData({
      showType:2,
    })
  },
  Anounce_btn(){
    /**
     * 查看公告
     */
    app.globalData.showType=1
    this.setData({
      showType:1,
    })
    console.log(this.data.showType)
  },
  SkipToDetail(e){
    /**
     * 跳转到投票详细页面
     */
    //获取点中投票的id，并设置全局的静态变量
    app.globalData.voteid=e.currentTarget.dataset['id']
    // console.log( app.globalData.voteid)
    wx.navigateTo({
      url: '/pages/votedetail/votedetail',
    })

  },
  SkipToSelect(e){
    /**
     * 跳转到选择投票界面
     */
    app.globalData.voteid=e.currentTarget.dataset['id']
    wx.navigateTo({
      url: '/pages/voteselect/voteselect',
    })
  },
  SkipToAnnouce(e){
    /**
     * 跳转到公告查看界面
     */
    app.globalData.announceid=e.currentTarget.dataset['id']
    wx.navigateTo({
      url: '/pages/annouceshow/annouceshow',
    })
  }
})