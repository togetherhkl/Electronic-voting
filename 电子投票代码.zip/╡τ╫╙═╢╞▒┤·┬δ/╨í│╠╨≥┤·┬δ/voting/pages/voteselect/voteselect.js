// pages/voteselect/voteselect.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    voteinfo:[],
    options:[],
    involoptions:[],//已经选中的投票记录，用于展示
    participate:null,
    radiooption_id:null,//单选ID
    multyoptions:[],//多选id
    btn_disable:false,//未参与状态的投票按钮
    currentTime:new Date().toJSON().substring(5, 10) + ' ' + new Date().toTimeString().substring(0,6),//获取当前时间
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that=this
    wx.request({
      url: app.api_root+'vote/select/info/', 
      method:'POST',
      data:{
        voteid:app.globalData.voteid,
        username:app.globalData.name,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
      },
      dataType:'json',
      success:function(res){
        console.log('单选',res)
        //单选选中的标记颜色
        let options=res.data.options
        for(let i in options){
          if(options[i]['check']){
            // console.log(options[i]['id'])
            that.setData({
              radiooption_id:options[i]['id']
            })
          }
        }
        that.setData({
          voteinfo:res.data.vote_instance[0],
          options:res.data.options,
          involoptions:res.data.options,
          participate:res.data.partici,
        })
        //如果参与，改变按钮状态
        if(res.data.partici){
          that.setData({
            btn_disable:true,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  RadioStyleChange(e){
    /**
     * 单选选中事件
     */
    this.setData({
      radiooption_id:e.target.dataset.id
    })
  },
  MultyStyleChange(e){
    // console.log(e)
    let id=e.currentTarget.dataset.id
    // console.log(this.data.multyoptions)
    // console.log(this.data.options)
    if (this.data.multyoptions.indexOf(id) > -1) {
      this.data.multyoptions.splice(this.data.multyoptions.indexOf(id), 1)
    } else {
      this.data.multyoptions.push(id)
    }

    //点击的样式修改
    let options=this.data.options
    // console.log(options)
    for(var i in options){
      if(options[i]['id']==id){
        if(options[i]['check']==true){
          options[i]['check']=false
        }
        else if(options[i]['check']==false){
          options[i]['check']=true
        } 
      }
    }
    this.setData({
      options:options
    })
    // console.log(this.data.multyoptions)
  },
  VoteSubmit(e){
    // console.log(this.data.voteinfo)
    if(this.data.currentTime>this.data.voteinfo.vote_deadtime){
      wx.showModal({
        title: "温馨提示", // 提示的标题
        content: "投票时间已经结束，不能再投票了！", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelText: "取消", // 取消按钮的文字，最多4个字符
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
        success: function (res) {
            // console.log("接口调用成功的回调函数");
            if (res.confirm) {
                // console.log('用户点击确定')
                return
            } else if (res.cancel) {
                // console.log('用户点击取消')
                return
            }
        },
        fail: function () {
            // console.log("接口调用失败的回调函数");
        },
        complete: function () {
            // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");
        }
    })
    return
    }
    let voteinfo=this.data.voteinfo
    if(voteinfo['vote_multiple']==1){//单选
      wx.request({
        url: app.api_root+'vote/select/submit/',
        data:{
          'vote_id':app.globalData.voteid,
          'username':app.globalData.name,
          'option_id':this.data.radiooption_id,
          'type':'radio'
        },
        dataType:'json',
        method:'POST',
        header:{
          'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
        },
        success(res){
          wx.showToast({
            title: res.data.msg,
            icon: 'success',
            duration: 2000
          })
          setTimeout(function(){
            wx.switchTab({//跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
              url: "/pages/home/home"
            });
          },2000)
        }
      })
    }
    if(voteinfo['vote_multiple']>1){//多选
      let optionlen=this.data.multyoptions.length
      if(optionlen>voteinfo['vote_multiple']){
        let content='只能选取'+voteinfo['vote_multiple']+'项'
        app. hintComifg(content)
        return
      }
      // console.log(this.data.multyoptions)
      wx.request({
        url: app.api_root+'vote/select/submit/',
        data:{
          'vote_id':app.globalData.voteid,
          'username':app.globalData.name,
          'option_list':this.data.multyoptions,
          'type':'multy'
        },
        dataType:'json',
        method:'POST',
        header:{
          'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
        },
        success(res){
          wx.showToast({
            title: res.data.msg,
            icon: 'success',
            duration: 2000
          })
          setTimeout(function(){
            wx.switchTab({//跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
              url: "/pages/home/home"
            });
          },2000)
          
        }
      })
    }
  },
})