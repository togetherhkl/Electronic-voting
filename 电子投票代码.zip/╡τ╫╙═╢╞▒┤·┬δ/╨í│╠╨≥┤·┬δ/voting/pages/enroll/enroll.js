// pages/enroll/enroll.js
let app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '', // 用户名
    password: '', // 密码
    phone:'',//手机号
  },

  // 获取手机号
  username(e) {
    this.setData({
      username: e.detail.value
    });
  },
  //获取手机号
  phone(e){
    this.setData({
      phone: e.detail.value
    });
  },
  // 获取密码
  password(e) {
    this.setData({
      password: e.detail.value
    });
  },


  // 确定按钮
  butConfirm() {
    var username = this.data.username,
        password = this.data.password,
        phone=this.data.phone
    console.log(username, password)

    // 信息不全
    if (username == "" || password == "" || phone=="") {
      app.hintComifg("请完善用户信息");
      return false;
    };

    // 手机号验证
    var myreg = /^[1]([3-9])[0-9]{9}$/;
    if (!myreg.test(this.data.phone)) {
      app.hintComifg("请输入正确的手机号");
      return false;
    };

    let that=this
    wx.request({
      url: 'http://192.168.198.254:8002/api/account/register/',
      dataType:'json',
      method:'POST',
      data:{
        'username':username,
        'password':password,
        'phone':phone
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' //POST请求一定要加上这么一句
      },
      success:function(res){
        if(res.statusCode==400){
          app.hintComifg(res.data.msg);
        }
        if(res.statusCode==200){
          app.hintComifg(res.data.msg);
          setTimeout(function(res){
            wx.navigateTo({
              url: '/pages/login/login',
            })
          },1000)
          
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})