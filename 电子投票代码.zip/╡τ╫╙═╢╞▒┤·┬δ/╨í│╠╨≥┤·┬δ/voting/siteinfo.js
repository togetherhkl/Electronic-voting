module.exports = {
  //module.exports的作用，本质上就是封装代码的作用，将常用的网络请求的代码、公共的变量放在里面。另外，module.//exports可以放在任何一个js里面。
  version: "1.0.0",
  name: "电子投票",
  siteroot: "http://192.168.198.254:8002/",
};